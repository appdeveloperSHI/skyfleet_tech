package com.sky.SkyFleetDriver.model

data class locationModel(
    val Vehicle: List<Vehicle>
)