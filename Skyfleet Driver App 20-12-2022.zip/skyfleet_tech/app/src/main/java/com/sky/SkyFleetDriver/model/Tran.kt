package com.sky.SkyFleetDriver.model

data class Tran(
    val amount: String,
    val date: String,
    val destination: String,
    val name: String,
    val origin: String,
    val year: String,
    val month: String,
    val day: String
)