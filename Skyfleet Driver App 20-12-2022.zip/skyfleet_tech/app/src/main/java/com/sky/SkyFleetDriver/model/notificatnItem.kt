package com.sky.SkyFleetDriver.model

/** By vincent 06/08/2021 */

data class notificatnItem(
    val date: String,
    val id: String,
    val msg: String,
    val rid: String
)