package com.sky.SkyFleetDriver.model

data class profileData(
    val ResponseCode: String,
    val ResponseMsg: String,
    val Result: String,
    val rider: Rider
)