package com.sky.SkyFleetDriver.model

data class otp(
    val ResponseCode: String,
    val ResponseMsg: String,
    val Result: String,
    val verification: Boolean
)