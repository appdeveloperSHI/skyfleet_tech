package com.sky.SkyFleetDriver.model

data class onlineStatus(
    val ResponseCode: String,
    val ResponseMsg: String,
    val Result: String
)