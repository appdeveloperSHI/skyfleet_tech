//data class Job(
//    val customermobile: String,
//    val customername: String,
//    val destination_location: String,
//    val est_ex_hr_charge: String,
//    val est_ex_km_charge: String,
//    val est_trip_time: String,
//    val job_id: String,
//    val origin_location: String,
//    val paymenttype: String,
//    val schedule_date: String,
//    val schedule_time: String,
//    val status: String,
//    val total_distance: Int,
//    val total_price: String,
//    val vid: String
//)